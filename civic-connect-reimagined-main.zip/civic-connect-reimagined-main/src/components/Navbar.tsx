import { Link, useLocation } from "react-router-dom";
import { ClipboardList, PlusCircle, Bell, Shield } from "lucide-react";
import { getUnreadCount } from "@/lib/store";

const navItems = [
  { to: "/", label: "Issue Feed", icon: ClipboardList },
  { to: "/report", label: "Report Issue", icon: PlusCircle },
  { to: "/notifications", label: "Notifications", icon: Bell },
  { to: "/authority", label: "Authority Login", icon: Shield },
];

const Navbar = () => {
  const { pathname } = useLocation();
  const unread = getUnreadCount();

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background">
      <div className="container mx-auto flex h-14 items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2 font-bold text-lg text-foreground">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary">
            <ClipboardList className="h-4 w-4 text-primary-foreground" />
          </div>
          CivicsTrack
        </Link>
        <nav className="hidden md:flex items-center gap-1">
          {navItems.map(({ to, label, icon: Icon }) => (
            <Link
              key={to}
              to={to}
              className={`relative flex items-center gap-1.5 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                pathname === to
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon className="h-4 w-4" />
              {label}
              {to === "/notifications" && unread > 0 && (
                <span className="absolute -top-0.5 -right-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">
                  {unread}
                </span>
              )}
            </Link>
          ))}
        </nav>
        {/* Mobile nav */}
        <nav className="flex md:hidden items-center gap-0.5">
          {navItems.map(({ to, icon: Icon }) => (
            <Link
              key={to}
              to={to}
              className={`relative rounded-md p-2 ${
                pathname === to ? "text-primary" : "text-muted-foreground"
              }`}
            >
              <Icon className="h-5 w-5" />
              {to === "/notifications" && unread > 0 && (
                <span className="absolute -top-0.5 -right-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">
                  {unread}
                </span>
              )}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default Navbar;
