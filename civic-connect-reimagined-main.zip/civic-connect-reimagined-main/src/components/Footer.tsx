import { ClipboardList } from "lucide-react";

const Footer = () => (
  <footer className="border-t border-border bg-background py-8">
    <div className="container mx-auto flex flex-col items-center gap-2 px-4 text-center">
      <div className="flex items-center gap-2 font-bold text-foreground">
        <div className="flex h-6 w-6 items-center justify-center rounded bg-primary">
          <ClipboardList className="h-3 w-3 text-primary-foreground" />
        </div>
        CivicsTrack
      </div>
      <p className="text-sm text-muted-foreground">
        © 2026 CivicsTrack. Empowering communities through transparency.
      </p>
    </div>
  </footer>
);

export default Footer;
