import { Link } from "react-router-dom";
import { MapPin, ChevronUp, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { Issue } from "@/lib/store";
import { formatDistanceToNow } from "date-fns";

const statusColors: Record<string, string> = {
  Open: "border-warning text-warning bg-warning/10",
  "In Progress": "border-info text-info bg-info/10",
  Resolved: "border-success text-success bg-success/10",
};

const priorityColors: Record<string, string> = {
  Low: "bg-muted text-muted-foreground",
  Med: "bg-warning/10 text-warning border-warning",
  High: "bg-destructive/10 text-destructive border-destructive",
};

const IssueCard = ({ issue }: { issue: Issue }) => (
  <Link
    to={`/issues/${issue.id}`}
    className="block rounded-lg border border-border bg-card p-5 transition-shadow hover:shadow-md"
  >
    <div className="flex items-start justify-between gap-3">
      <div className="flex flex-wrap items-center gap-2">
        <Badge variant="outline" className={statusColors[issue.status]}>
          {issue.status === "In Progress" && <Clock className="mr-1 h-3 w-3" />}
          {issue.status}
        </Badge>
        <Badge variant="outline" className={priorityColors[issue.priority]}>
          {issue.priority} Priority
        </Badge>
      </div>
      <div className="flex flex-col items-center text-muted-foreground">
        <ChevronUp className="h-4 w-4" />
        <span className="text-sm font-medium">{issue.upvotes}</span>
      </div>
    </div>
    <h3 className="mt-2 font-semibold text-card-foreground">{issue.title}</h3>
    <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{issue.description}</p>
    <div className="mt-3 flex items-center gap-1 text-xs text-muted-foreground">
      <MapPin className="h-3 w-3" />
      {issue.location}
    </div>
    <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
      <span>
        {issue.reporterName} • {formatDistanceToNow(new Date(issue.createdAt), { addSuffix: true })}
      </span>
      <span className="text-primary">{issue.category}</span>
    </div>
  </Link>
);

export default IssueCard;
