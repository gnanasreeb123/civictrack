export type IssueStatus = "Open" | "In Progress" | "Resolved";
export type Priority = "Low" | "Med" | "High";
export type Category =
  | "Road/Infrastructure"
  | "Water/Sewage"
  | "Electricity"
  | "Garbage/Waste"
  | "Parks/Recreation"
  | "Public Safety"
  | "Other";

export interface Comment {
  id: string;
  name: string;
  email: string;
  text: string;
  createdAt: string;
}

export interface Issue {
  id: number;
  title: string;
  description: string;
  category: Category;
  priority: Priority;
  status: IssueStatus;
  location: string;
  photoUrl?: string;
  reporterName: string;
  reporterEmail: string;
  upvotes: number;
  comments: Comment[];
  officialResponse?: string;
  createdAt: string;
  updatedAt: string;
}

const STORAGE_KEY = "civicreport_issues";
const NOTIF_KEY = "civicstrack_notifications";

export interface Notification {
  id: string;
  issueId: number;
  issueTitle: string;
  type: "status_change" | "comment" | "upvote" | "official_response" | "new_issue";
  message: string;
  read: boolean;
  createdAt: string;
}

function loadNotifications(): Notification[] {
  try {
    const raw = localStorage.getItem(NOTIF_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveNotifications(notifs: Notification[]) {
  localStorage.setItem(NOTIF_KEY, JSON.stringify(notifs));
}

function addNotification(issueId: number, issueTitle: string, type: Notification["type"], message: string) {
  const notifs = loadNotifications();
  notifs.unshift({
    id: crypto.randomUUID(),
    issueId,
    issueTitle,
    type,
    message,
    read: false,
    createdAt: new Date().toISOString(),
  });
  saveNotifications(notifs);
}

export function getNotifications(): Notification[] {
  return loadNotifications();
}

export function markNotificationRead(id: string) {
  const notifs = loadNotifications();
  const n = notifs.find((x) => x.id === id);
  if (n) { n.read = true; saveNotifications(notifs); }
}

export function markAllNotificationsRead() {
  const notifs = loadNotifications();
  notifs.forEach((n) => (n.read = true));
  saveNotifications(notifs);
}

export function getUnreadCount(): number {
  return loadNotifications().filter((n) => !n.read).length;
}

function loadIssues(): Issue[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveIssues(issues: Issue[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(issues));
}

export function getIssues(): Issue[] {
  return loadIssues().sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

export function getIssue(id: number): Issue | undefined {
  return loadIssues().find((i) => i.id === id);
}

export function createIssue(
  data: Omit<Issue, "id" | "upvotes" | "comments" | "officialResponse" | "createdAt" | "updatedAt">
): Issue {
  const issues = loadIssues();
  const id = issues.length > 0 ? Math.max(...issues.map((i) => i.id)) + 1 : 1;
  const now = new Date().toISOString();
  const issue: Issue = {
    ...data,
    id,
    upvotes: 0,
    comments: [],
    createdAt: now,
    updatedAt: now,
  };
  issues.push(issue);
  saveIssues(issues);
  addNotification(issue.id, issue.title, "new_issue", `New issue reported: "${issue.title}"`);
  return issue;
}

export function upvoteIssue(id: number): Issue | undefined {
  const issues = loadIssues();
  const issue = issues.find((i) => i.id === id);
  if (issue) {
    issue.upvotes += 1;
    issue.updatedAt = new Date().toISOString();
    saveIssues(issues);
    addNotification(issue.id, issue.title, "upvote", `Issue "${issue.title}" received an upvote (${issue.upvotes} total)`);
  }
  return issue;
}

export function addComment(id: number, name: string, email: string, text: string): Issue | undefined {
  const issues = loadIssues();
  const issue = issues.find((i) => i.id === id);
  if (issue) {
    issue.comments.push({
      id: crypto.randomUUID(),
      name,
      email,
      text,
      createdAt: new Date().toISOString(),
    });
    issue.updatedAt = new Date().toISOString();
    saveIssues(issues);
    addNotification(issue.id, issue.title, "comment", `${name} commented on "${issue.title}"`);
  }
  return issue;
}

export function updateIssueStatus(id: number, status: IssueStatus, officialResponse?: string): Issue | undefined {
  const issues = loadIssues();
  const issue = issues.find((i) => i.id === id);
  if (issue) {
    issue.status = status;
    if (officialResponse !== undefined) issue.officialResponse = officialResponse;
    issue.updatedAt = new Date().toISOString();
    saveIssues(issues);
    addNotification(issue.id, issue.title, "status_change", `Issue "${issue.title}" status changed to ${status}`);
    if (officialResponse) {
      addNotification(issue.id, issue.title, "official_response", `Official response added to "${issue.title}"`);
    }
  }
  return issue;
}
