import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { AlertTriangle, MapPin, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { createIssue, type Category, type Priority } from "@/lib/store";

const categories: Category[] = [
  "Road/Infrastructure",
  "Water/Sewage",
  "Electricity",
  "Garbage/Waste",
  "Parks/Recreation",
  "Public Safety",
  "Other",
];

const ReportIssue = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<Category | "">("");
  const [priority, setPriority] = useState<Priority>("Med");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [photoUrl, setPhotoUrl] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !category || !description || !location || !name || !email) {
      toast({ title: "Missing fields", description: "Please fill in all required fields.", variant: "destructive" });
      return;
    }
    const issue = createIssue({
      title,
      category: category as Category,
      priority,
      status: "Open",
      description,
      location,
      photoUrl: photoUrl || undefined,
      reporterName: name,
      reporterEmail: email,
    });
    toast({ title: "Issue reported!", description: `Issue #${String(issue.id).padStart(5, "0")} created.` });
    navigate(`/issues/${issue.id}`);
  };

  return (
    <div className="container mx-auto max-w-2xl px-4 py-10">
      <h1 className="text-3xl font-bold text-foreground">Report an Issue</h1>
      <p className="mt-1 text-muted-foreground">
        Help us improve the community by providing detailed information about the problem.
      </p>

      <form onSubmit={handleSubmit} className="mt-8 rounded-lg border border-border bg-card p-6 space-y-8">
        <div>
          <h2 className="text-lg font-semibold text-card-foreground">Issue Details</h2>
          <p className="text-sm text-muted-foreground">All fields marked with an asterisk (*) are required.</p>
        </div>

        {/* What's the problem? */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 border-b border-border pb-2">
            <AlertTriangle className="h-4 w-4 text-warning" />
            <h3 className="font-semibold text-card-foreground">What's the problem?</h3>
          </div>
          <div>
            <Label htmlFor="title">Short Title *</Label>
            <Input id="title" placeholder="e.g. Deep pothole on Main St" value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label>Category *</Label>
              <Select value={category} onValueChange={(v) => setCategory(v as Category)}>
                <SelectTrigger><SelectValue placeholder="Select a category" /></SelectTrigger>
                <SelectContent>
                  {categories.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Estimated Urgency *</Label>
              <Select value={priority} onValueChange={(v) => setPriority(v as Priority)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Low">Low - Routine maintenance</SelectItem>
                  <SelectItem value="Med">Medium - Causes inconvenience</SelectItem>
                  <SelectItem value="High">High - Safety hazard</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label htmlFor="desc">Detailed Description *</Label>
            <Textarea id="desc" rows={5} placeholder="Please describe the issue in detail, including any specific landmarks nearby..." value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
        </div>

        {/* Location & Evidence */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 border-b border-border pb-2">
            <MapPin className="h-4 w-4 text-primary" />
            <h3 className="font-semibold text-card-foreground">Location & Evidence</h3>
          </div>
          <div>
            <Label htmlFor="location">Street Address / Exact Location *</Label>
            <Input id="location" placeholder="e.g. 123 Elm St, near the crosswalk" value={location} onChange={(e) => setLocation(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="photo">Photo URL (Optional)</Label>
            <Input id="photo" placeholder="https://example.com/photo.jpg" value={photoUrl} onChange={(e) => setPhotoUrl(e.target.value)} />
            <p className="text-xs text-muted-foreground mt-1">Link to an image showing the issue (Unsplash URLs work for testing).</p>
          </div>
        </div>

        {/* Your Details */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 border-b border-border pb-2">
            <User className="h-4 w-4 text-primary" />
            <h3 className="font-semibold text-card-foreground">Your Details</h3>
          </div>
          <p className="text-sm text-muted-foreground">We need this to update you on the status of your report.</p>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="name">Full Name *</Label>
              <Input id="name" placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="email">Email Address *</Label>
              <Input id="email" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={() => navigate("/")}>Cancel</Button>
          <Button type="submit">Submit Report</Button>
        </div>
      </form>
    </div>
  );
};

export default ReportIssue;
