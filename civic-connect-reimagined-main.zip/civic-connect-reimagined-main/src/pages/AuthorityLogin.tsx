import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { getIssues, updateIssueStatus, type IssueStatus } from "@/lib/store";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

const AuthorityLogin = () => {
  const { toast } = useToast();
  const [loggedIn, setLoggedIn] = useState(false);
  const [password, setPassword] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "admin123") {
      setLoggedIn(true);
    } else {
      toast({ title: "Invalid password", variant: "destructive" });
    }
  };

  if (!loggedIn) {
    return (
      <div className="container mx-auto flex min-h-[60vh] max-w-sm flex-col items-center justify-center px-4">
        <Shield className="h-12 w-12 text-primary" />
        <h1 className="mt-4 text-2xl font-bold text-foreground">Authority Login</h1>
        <p className="mt-1 text-sm text-muted-foreground">Access the admin dashboard to manage issues.</p>
        <form onSubmit={handleLogin} className="mt-6 w-full space-y-4">
          <div>
            <Label htmlFor="pw">Password</Label>
            <Input id="pw" type="password" placeholder="Enter admin password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <Button type="submit" className="w-full">Login</Button>
          <p className="text-xs text-center text-muted-foreground">Demo password: admin123</p>
        </form>
      </div>
    );
  }

  return <AdminDashboard />;
};

const AdminDashboard = () => {
  const { toast } = useToast();
  const [issues, setIssues] = useState(getIssues());
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [newStatus, setNewStatus] = useState<IssueStatus>("Open");
  const [response, setResponse] = useState("");

  const handleUpdate = () => {
    if (selectedId === null) return;
    updateIssueStatus(selectedId, newStatus, response || undefined);
    setIssues(getIssues());
    setSelectedId(null);
    setResponse("");
    toast({ title: "Issue updated!" });
  };

  return (
    <div className="container mx-auto max-w-4xl px-4 py-10">
      <h1 className="text-2xl font-bold text-foreground">Admin Dashboard</h1>
      <p className="text-muted-foreground">Manage reported issues and update their status.</p>

      <div className="mt-6 space-y-3">
        {issues.map((issue) => (
          <div
            key={issue.id}
            onClick={() => { setSelectedId(issue.id); setNewStatus(issue.status); setResponse(issue.officialResponse || ""); }}
            className={`cursor-pointer rounded-lg border p-4 transition-colors ${
              selectedId === issue.id ? "border-primary bg-primary/5" : "border-border bg-card hover:border-primary/40"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="font-medium text-card-foreground">#{String(issue.id).padStart(5, "0")} — {issue.title}</span>
              <span className="text-xs text-muted-foreground">{issue.status}</span>
            </div>
          </div>
        ))}
      </div>

      {selectedId !== null && (
        <div className="mt-6 rounded-lg border border-border bg-card p-6 space-y-4">
          <h2 className="font-semibold text-card-foreground">Update Issue #{String(selectedId).padStart(5, "0")}</h2>
          <div>
            <Label>Status</Label>
            <Select value={newStatus} onValueChange={(v) => setNewStatus(v as IssueStatus)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Open">Open</SelectItem>
                <SelectItem value="In Progress">In Progress</SelectItem>
                <SelectItem value="Resolved">Resolved</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Official Response</Label>
            <Textarea placeholder="Add an official response..." value={response} onChange={(e) => setResponse(e.target.value)} />
          </div>
          <Button onClick={handleUpdate}>Save Changes</Button>
        </div>
      )}
    </div>
  );
};

export default AuthorityLogin;
