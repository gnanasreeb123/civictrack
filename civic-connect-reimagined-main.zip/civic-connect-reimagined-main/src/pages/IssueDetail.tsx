import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Calendar, MapPin, ChevronUp, MessageSquare, ShieldCheck, User } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { getIssue, upvoteIssue, addComment, type Issue } from "@/lib/store";
import { format, formatDistanceToNow } from "date-fns";

const statusColors: Record<string, string> = {
  Open: "border-warning text-warning bg-warning/10",
  "In Progress": "border-info text-info bg-info/10",
  Resolved: "border-success text-success bg-success/10",
};
const priorityColors: Record<string, string> = {
  Low: "bg-muted text-muted-foreground",
  Med: "bg-warning/10 text-warning border-warning",
  High: "bg-destructive/10 text-destructive border-destructive",
};

const IssueDetail = () => {
  const { id } = useParams();
  const { toast } = useToast();
  const [issue, setIssue] = useState<Issue | undefined>(() => getIssue(Number(id)));
  const [commentName, setCommentName] = useState("");
  const [commentEmail, setCommentEmail] = useState("");
  const [commentText, setCommentText] = useState("");

  if (!issue) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <p className="text-muted-foreground">Issue not found.</p>
        <Link to="/" className="mt-4 inline-block text-primary underline">Back to issues</Link>
      </div>
    );
  }

  const handleUpvote = () => {
    const updated = upvoteIssue(issue.id);
    if (updated) setIssue({ ...updated });
  };

  const handleComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentName || !commentEmail || !commentText) {
      toast({ title: "Missing fields", variant: "destructive" });
      return;
    }
    const updated = addComment(issue.id, commentName, commentEmail, commentText);
    if (updated) {
      setIssue({ ...updated });
      setCommentName("");
      setCommentEmail("");
      setCommentText("");
      toast({ title: "Comment posted!" });
    }
  };

  return (
    <div className="container mx-auto max-w-5xl px-4 py-6">
      <Link to="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="h-4 w-4" /> Back to all issues
      </Link>

      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        {/* Main */}
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="outline" className={statusColors[issue.status]}>{issue.status}</Badge>
            <Badge variant="outline" className={priorityColors[issue.priority]}>{issue.priority} Priority</Badge>
            <Badge variant="outline" className="bg-muted">{issue.category}</Badge>
          </div>
          <h1 className="mt-3 text-3xl font-bold text-foreground">{issue.title}</h1>
          <div className="mt-2 flex flex-wrap gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" />{format(new Date(issue.createdAt), "MMMM d, yyyy 'at' h:mm a")}</span>
            <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{issue.location}</span>
          </div>

          {issue.photoUrl && (
            <img src={issue.photoUrl} alt="Issue" className="mt-4 rounded-lg border border-border max-h-64 object-cover w-full" />
          )}

          <div className="mt-6">
            <h2 className="text-xl font-semibold text-foreground">Description</h2>
            <p className="mt-2 text-muted-foreground whitespace-pre-wrap">{issue.description}</p>
          </div>

          <hr className="my-6 border-border" />

          {/* Discussion */}
          <div>
            <h2 className="flex items-center gap-2 text-xl font-semibold text-foreground">
              <MessageSquare className="h-5 w-5" /> Discussion ({issue.comments.length})
            </h2>
            {issue.comments.length === 0 && (
              <p className="mt-3 italic text-muted-foreground">No comments yet. Be the first to add details.</p>
            )}
            <div className="mt-4 space-y-4">
              {issue.comments.map((c) => (
                <div key={c.id} className="rounded-lg border border-border bg-muted/50 p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-foreground">{c.name}</span>
                    <span className="text-xs text-muted-foreground">{formatDistanceToNow(new Date(c.createdAt), { addSuffix: true })}</span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{c.text}</p>
                </div>
              ))}
            </div>

            <form onSubmit={handleComment} className="mt-6 rounded-lg border border-border bg-card p-4 space-y-3">
              <h3 className="font-semibold text-card-foreground">Add a comment</h3>
              <div className="grid gap-3 sm:grid-cols-2">
                <Input placeholder="Your Name" value={commentName} onChange={(e) => setCommentName(e.target.value)} />
                <Input placeholder="Your Email" type="email" value={commentEmail} onChange={(e) => setCommentEmail(e.target.value)} />
              </div>
              <Textarea placeholder="Share updates or ask questions..." value={commentText} onChange={(e) => setCommentText(e.target.value)} rows={3} />
              <div className="flex justify-end">
                <Button type="submit">Post Comment</Button>
              </div>
            </form>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          <div className="rounded-lg border border-border bg-card p-6 text-center">
            <p className="text-sm font-medium text-muted-foreground">Community Support</p>
            <p className="my-2 text-4xl font-bold text-primary">{issue.upvotes}</p>
            <Button onClick={handleUpvote} className="w-full">
              <ChevronUp className="mr-1 h-4 w-4" /> Upvote this Issue
            </Button>
            <p className="mt-2 text-xs text-muted-foreground">Upvote to increase priority for local authorities.</p>
          </div>

          {issue.officialResponse && (
            <div className="rounded-lg border border-border bg-card p-5">
              <h3 className="flex items-center gap-2 font-semibold text-primary">
                <ShieldCheck className="h-4 w-4" /> Official Response
              </h3>
              <p className="mt-2 rounded bg-muted p-3 text-sm text-muted-foreground">{issue.officialResponse}</p>
            </div>
          )}

          <div className="rounded-lg border border-border bg-card p-5 space-y-3">
            <h3 className="font-semibold text-card-foreground">Report Info</h3>
            <div>
              <p className="text-xs font-medium uppercase text-muted-foreground">Reported By</p>
              <p className="flex items-center gap-1 text-sm text-foreground"><User className="h-3 w-3" />{issue.reporterName}</p>
            </div>
            <div>
              <p className="text-xs font-medium uppercase text-muted-foreground">Issue ID</p>
              <p className="text-sm text-foreground">#{String(issue.id).padStart(5, "0")}</p>
            </div>
            <div>
              <p className="text-xs font-medium uppercase text-muted-foreground">Last Updated</p>
              <p className="text-sm text-foreground">{format(new Date(issue.updatedAt), "MMM d, yyyy")}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IssueDetail;
