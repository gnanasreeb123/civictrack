import { useState } from "react";
import { Link } from "react-router-dom";
import { Bell, CheckCheck, MessageSquare, ChevronUp, ShieldCheck, AlertTriangle, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getNotifications, markNotificationRead, markAllNotificationsRead, type Notification } from "@/lib/store";
import { formatDistanceToNow } from "date-fns";

const iconMap: Record<Notification["type"], typeof Bell> = {
  status_change: AlertTriangle,
  comment: MessageSquare,
  upvote: ChevronUp,
  official_response: ShieldCheck,
  new_issue: Plus,
};

const Notifications = () => {
  const [notifications, setNotifications] = useState<Notification[]>(() => getNotifications());

  const handleMarkAllRead = () => {
    markAllNotificationsRead();
    setNotifications(getNotifications());
  };

  const handleClick = (id: string) => {
    markNotificationRead(id);
    setNotifications(getNotifications());
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="container mx-auto max-w-2xl px-4 py-10">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Bell className="h-6 w-6" /> Notifications
            {unreadCount > 0 && (
              <Badge variant="destructive" className="text-xs">{unreadCount}</Badge>
            )}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Stay updated on your reported issues</p>
        </div>
        {unreadCount > 0 && (
          <Button variant="outline" size="sm" onClick={handleMarkAllRead}>
            <CheckCheck className="mr-1 h-4 w-4" /> Mark all read
          </Button>
        )}
      </div>

      <div className="mt-6 space-y-2">
        {notifications.length === 0 ? (
          <div className="py-16 text-center">
            <Bell className="mx-auto h-12 w-12 text-muted-foreground" />
            <p className="mt-4 text-muted-foreground">No notifications yet. Report an issue or interact with existing ones to see updates here.</p>
          </div>
        ) : (
          notifications.map((n) => {
            const Icon = iconMap[n.type];
            return (
              <Link
                key={n.id}
                to={`/issues/${n.issueId}`}
                onClick={() => handleClick(n.id)}
                className={`flex items-start gap-3 rounded-lg border p-4 transition-colors hover:bg-muted/50 ${
                  n.read ? "border-border bg-card" : "border-primary/30 bg-primary/5"
                }`}
              >
                <div className={`mt-0.5 rounded-md p-1.5 ${n.read ? "bg-muted text-muted-foreground" : "bg-primary/10 text-primary"}`}>
                  <Icon className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`text-sm ${n.read ? "text-muted-foreground" : "text-foreground font-medium"}`}>
                    {n.message}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {formatDistanceToNow(new Date(n.createdAt), { addSuffix: true })}
                  </p>
                </div>
                {!n.read && <div className="mt-2 h-2 w-2 rounded-full bg-primary shrink-0" />}
              </Link>
            );
          })
        )}
      </div>
    </div>
  );
};

export default Notifications;
